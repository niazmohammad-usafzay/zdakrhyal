const API=location.origin;
let navigatingBack=false;

function navigate(screen, render){
  if(!navigatingBack){
    history.pushState({zdScreen:screen},"","#"+screen);
  }
  render();
}

window.addEventListener("popstate",function(e){
  navigatingBack=true;
  const screen=e.state&&e.state.zdScreen;

  if(screen==="login"){
    showLogin();
  }else if(screen==="register"){
    showRegister();
  }else{
    document.getElementById("content").innerHTML="";
  }

  navigatingBack=false;
});

if(!history.state || !history.state.zdScreen){
  history.replaceState({zdScreen:"home"},"","#home");
}
async function catalog(){
  const r=await fetch(API+"/api/academic/catalog");
  if(!r.ok) throw new Error("Academic معلومات ترلاسه نه شول");
  return r.json();
}

function logout(){
  localStorage.removeItem("zd");
  localStorage.removeItem("zd_token");
  localStorage.removeItem("zd_user");
  navigatingBack=false;
  showLogin();
}

function showLogin(fromHistory=false){
  const render=()=>{
    document.getElementById("content").innerHTML=
      '<div class="card"><h2>Login</h2><div class="form">'+
      '<input id="phone" placeholder="د موبایل شمېره">'+
      '<input id="password" type="password" placeholder="پټ نوم">'+
      '<button onclick="login()">ننوتل</button></div></div>';
  };

  if(!fromHistory){
    navigate("login",render);
  }else{
    render();
  }
}

async function showRegister(fromHistory=false){
  const render=async()=>{
  try{
    const a=await catalog();
    window.academic=a;

    const universities=(a.universities||[]).map(x=>{
      const v=x.name||x.id||"";
      return '<option value="'+v+'">'+v+'</option>';
    }).join("");

    const faculties=(a.faculties||[]).map(x=>{
      const v=x.name||x.id||"";
      return '<option value="'+v+'">'+v+'</option>';
    }).join("");

    const years=(a.academicYears||[]).map(x=>{
      const v=x.name||x.year||x.id||"";
      return '<option value="'+v+'">'+v+'</option>';
    }).join("");

    document.getElementById("content").innerHTML=
      '<div class="card"><h2>نوی حساب</h2><div class="form">'+
      '<input id="name" placeholder="بشپړ نوم">'+
      '<input id="phone" placeholder="د موبایل شمېره">'+
      '<select id="university"><option value="">پوهنتون انتخاب کړئ</option>'+universities+'</select>'+
      '<select id="faculty" onchange="loadDepartments()"><option value="">پوهنځی انتخاب کړئ</option>'+faculties+'</select>'+
      '<select id="department"><option value="">رشته انتخاب کړئ</option></select>'+
      '<select id="semester"><option value="">سمستر انتخاب کړئ</option></select>'+
      '<select id="academicYear"><option value="">تحصیلي کال انتخاب کړئ</option>'+years+'</select>'+
      '<input id="password" type="password" placeholder="Password">'+
      '<input id="passwordConfirm" type="password" placeholder="Password بیا ولیکئ">'+
      '<label><input id="terms" type="checkbox"> شرایط منم</label>'+
      '<button onclick="register()">ثبت نام</button></div></div>';
  }catch(e){
    alert(e.message);
  }
  };

  if(!fromHistory){
    navigate("register",render);
  }else{
    render();
  }
}

function loadDepartments(){
  const f=document.getElementById("faculty").value;
  const deps=(window.academic.departments||[]).filter(x=>{
    return String(x.faculty||x.facultyId||"")===String(f);
  });

  document.getElementById("department").innerHTML=
    '<option value="">رشته انتخاب کړئ</option>'+
    deps.map(x=>{
      const v=x.name||x.id||"";
      return '<option value="'+v+'">'+v+'</option>';
    }).join("");

  const count=Number((window.academic.facultySemesters||{})[f]||0);
  document.getElementById("semester").innerHTML=
    '<option value="">سمستر انتخاب کړئ</option>'+
    Array.from({length:count},(_,i)=>
      '<option value="'+(i+1)+'">'+(i+1)+' سمستر</option>'
    ).join("");
}

async function register(){
  const body={
    name:document.getElementById("name").value.trim(),
    phone:document.getElementById("phone").value.trim(),
    university:document.getElementById("university").value,
    faculty:document.getElementById("faculty").value,
    department:document.getElementById("department").value,
    semester:document.getElementById("semester").value,
    academicYear:document.getElementById("academicYear").value,
    password:document.getElementById("password").value,
    passwordConfirm:document.getElementById("passwordConfirm").value,
    acceptTerms:document.getElementById("terms").checked
  };

  try{
    const r=await fetch(API+"/api/register",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify(body)
    });
    const d=await r.json();
    if(!r.ok) throw new Error(d.error||"ثبت نام ناکام شو");

    document.getElementById("content").innerHTML=
      '<div class="card"><h2>ثبت نام بریالی شو</h2>'+
      '<p>'+d.message+'</p>'+
      '<p><b>Student Code:</b> '+d.studentCode+'</p>'+
      '<button onclick="showLogin()">Login</button></div>';
  }catch(e){
    alert(e.message);
  }
}

async function login(){alert("LOGIN FUNCTION اجرا شو");
  const identifier=document.getElementById("phone").value.trim();
  const password=document.getElementById("password").value;

  try{
    const r=await fetch(API+"/api/login",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({
        identifier,
        password,
        deviceId:"mobile-web"
      })
    });

    const raw=await r.text();
    let d;
    try{
      d=JSON.parse(raw);
    }catch(e){
      throw new Error("Login API JSON نه دی: "+raw.slice(0,200));
    }
    if(!r.ok) throw new Error(d.error||"Login ناکام شو");

    localStorage.setItem("zd",d.token);localStorage.setItem("zd_token",d.token);
    localStorage.setItem("zd_user",JSON.stringify(d.user));

    showDashboard(d.user);
  }catch(e){
    alert(e.message);
  }
}
async function showDashboard(user){
  const c=document.getElementById("content");

  c.innerHTML=
    '<div class="dashboard-loading">'+
      '<div class="loading-icon">📚</div>'+
      '<h3>Dashboard چمتو کېږي...</h3>'+
      '<p>مهرباني وکړئ لږ انتظار وکړئ</p>'+
    '</div>';

  const token=localStorage.getItem("zd")||localStorage.getItem("zd_token");
  if(!token){
    c.innerHTML='<div class="card"><h2>Login اړین دی</h2><p>مهرباني وکړئ بیا Login وکړئ.</p></div>';
    return;
  }

  const headers={Authorization:"Bearer "+token};

  async function safeGet(url,fallback){
    try{
      const r=await fetch(API+url,{headers});
      const text=await r.text();

      if(!text || !text.trim()){
        return fallback;
      }

      let data;
      try{
        data=JSON.parse(text);
      }catch(e){
        console.warn("Non-JSON response:",url,text.slice(0,100));
        return fallback;
      }

      if(!r.ok){
        console.warn("API error:",url,r.status);
        return fallback;
      }

      return data;
    }catch(e){
      console.warn("Request failed:",url,e.message);
      return fallback;
    }
  }

  try{
    const [
      me,
      subjects,
      courses,
      books,
      purchases,
      progress,
      notifications,
      transcript,
      attendance
    ]=await Promise.all([
      safeGet("/api/me",{user:user}),
      safeGet("/api/student/subjects",{subjects:[]}),
      safeGet("/api/courses",{courses:[]}),
      safeGet("/api/books",{books:[]}),
      safeGet("/api/my-purchases",{purchases:[]}),
      safeGet("/api/my-progress",{progress:[]}),
      safeGet("/api/notifications",{notifications:[]}),
      safeGet("/api/student/transcript",{records:[],totalCredits:0,gpa:0}),
      safeGet("/api/student/attendance",{attendance:[]})
    ]);

    const u=(me&&me.user)||user||{};

    const subjectList=Array.isArray(subjects.subjects)?subjects.subjects:[];
    const courseList=Array.isArray(courses.courses)?courses.courses:[];
    const bookList=Array.isArray(books.books)?books.books:[];
    const purchaseList=Array.isArray(purchases.purchases)?purchases.purchases:[];
    const progressList=Array.isArray(progress.progress)?progress.progress:[];
    const notificationList=Array.isArray(notifications.notifications)?notifications.notifications:[];
    const transcriptList=Array.isArray(transcript.records)?transcript.records:[];
    const attendanceList=Array.isArray(attendance.attendance)?attendance.attendance:[];

    const esc=x=>String(x??"")
      .replace(/&/g,"&amp;")
      .replace(/</g,"&lt;")
      .replace(/>/g,"&gt;")
      .replace(/"/g,"&quot;");

    const firstName=esc((u.name||"محصل").split(" ")[0]);
    const gpa=Number(transcript.gpa||0);
    const credits=Number(transcript.totalCredits||0);

    const avgAttendance=attendanceList.length
      ? Math.round(
          attendanceList.reduce((sum,x)=>sum+Number(x.percent||0),0)/
          attendanceList.length
        )
      : 0;

    const items=(arr,empty,fn)=>{
      if(!arr.length)
        return '<div class="empty-state">'+empty+'</div>';
      return arr.slice(0,8).map(fn).join("");
    };

    c.innerHTML=
      '<div class="student-hero">'+
        '<div class="hero-top">'+
          '<div class="avatar">'+esc((u.name||"م").charAt(0))+'</div>'+
          '<div class="hero-info">'+
            '<span class="welcome">ښه راغلاست 👋</span>'+
            '<h2>'+firstName+'</h2>'+
            '<p>'+esc(u.studentCode||"Student")+'</p>'+
          '</div>'+
          '<button onclick="logout()" class="logout-btn">وتل</button><div class="status-pill"><span></span>'+esc(u.status||"verified")+'</div>'+
        '</div>'+
        '<div class="academic-info">'+
          '<div><small>پوهنتون</small><b>'+esc(u.university||"—")+'</b></div>'+
          '<div><small>پوهنځی</small><b>'+esc(u.faculty||"—")+'</b></div>'+
          '<div><small>رشته</small><b>'+esc(u.department||"—")+'</b></div>'+
          '<div><small>سمستر</small><b>'+esc(u.semester||"—")+'</b></div>'+
        '</div>'+
      '</div>'+

      '<div class="stats-grid">'+
        '<div class="stat-card"><div class="stat-icon">📚</div><strong>'+subjectList.length+'</strong><span>مضمونونه</span></div>'+
        '<div class="stat-card"><div class="stat-icon">🎓</div><strong>'+courseList.length+'</strong><span>کورسونه</span></div>'+
        '<div class="stat-card"><div class="stat-icon">⭐</div><strong>'+esc(gpa)+'</strong><span>GPA</span></div>'+
        '<div class="stat-card"><div class="stat-icon">📅</div><strong>'+avgAttendance+'%</strong><span>اوسط حاضري</span></div>'+
      '</div>'+

      '<section class="dash-section">'+
        '<div class="section-title"><div><span class="section-icon">📚</span><h3>زما مضمونونه</h3></div><span class="count-badge">'+subjectList.length+'</span></div>'+
        items(subjectList,"تر اوسه مضمونونه نشته",x=>
          '<div class="subject-card"><div class="item-icon">📖</div><div class="item-main"><b>'+esc(x.name||x.title||x.subject||"مضمون")+'</b><span>'+esc(x.code||"مضمون")+'</span></div>'+(x.semester?'<div class="semester-badge">'+esc(x.semester)+' سمستر</div>':"")+'</div>'
        )+
      '</section>'+

      '<section class="dash-section">'+
        '<div class="section-title"><div><span class="section-icon">🎓</span><h3>کورسونه</h3></div><span class="count-badge">'+courseList.length+'</span></div>'+
        items(courseList,"تر اوسه کورس نشته",x=>
          '<div class="course-card"><div class="course-icon">🎓</div><div class="item-main"><b>'+esc(x.title||x.name||"کورس")+'</b><span>'+esc(x.description||"تعلیمي کورس")+'</span></div></div>'
        )+
      '</section>'+

      '<section class="dash-section">'+
        '<div class="section-title"><div><span class="section-icon">📖</span><h3>کتابتون</h3></div><span class="count-badge">'+bookList.length+'</span></div>'+
        items(bookList,"تر اوسه کتاب نشته",x=>
          '<div class="book-card"><div class="book-icon">📕</div><div class="item-main"><b>'+esc(x.title||x.name||"کتاب")+'</b><span>'+esc(x.author||"لیکوال نه دی ثبت شوی")+'</span></div></div>'
        )+
      '</section>'+

      '<section class="dash-section">'+
        '<div class="section-title"><div><span class="section-icon">📈</span><h3>زده کړې Progress</h3></div></div>'+
        items(progressList,"تر اوسه Progress نشته",x=>{
          let percent=x.progress;
          if(percent&&typeof percent==="object") percent=percent.percent??percent.progress??0;
          percent=Math.max(0,Math.min(100,Number(percent||0)));
          return '<div class="progress-card"><div class="progress-head"><b>'+esc(x.title||x.courseTitle||"کورس")+'</b><strong>'+percent+'%</strong></div><div class="progress-track"><div class="progress-fill" style="width:'+percent+'%"></div></div></div>';
        })+
      '</section>'+

      '<section class="dash-section">'+
        '<div class="section-title"><div><span class="section-icon">⭐</span><h3>Transcript / نمرې</h3></div><span class="count-badge">'+transcriptList.length+'</span></div>'+
        '<div class="transcript-summary"><b>GPA: '+esc(gpa)+'</b><span>ټول Credits: '+esc(credits)+'</span></div>'+
        items(transcriptList,"تر اوسه نمرې ثبت شوې نه دي",x=>
          '<div class="transcript-row"><b>'+esc(x.subjectName||x.title||x.subjectId||"مضمون")+'</b><span>'+esc(x.grade||x.gradePoint||"—")+'</span></div>'
        )+
      '</section>'+

      '<section class="dash-section">'+
        '<div class="section-title"><div><span class="section-icon">📅</span><h3>حاضري</h3></div><span class="count-badge">'+attendanceList.length+'</span></div>'+
        items(attendanceList,"تر اوسه د حاضرۍ معلومات نشته",x=>
          '<div class="attendance-card"><div class="attendance-head"><b>'+esc(x.subjectName||x.subject||"مضمون")+'</b><strong>'+esc(x.percent||0)+'%</strong></div><div class="attendance-track"><div class="attendance-fill" style="width:'+Math.min(100,Number(x.percent||0))+'%"></div></div><div class="attendance-numbers"><span>حاضر: '+esc(x.present||0)+'</span><span>غیرحاضر: '+esc(x.absent||0)+'</span><span>ناوخته: '+esc(x.late||0)+'</span></div></div>'
        )+
      '</section>'+

      '<section class="dash-section">'+
        '<div class="section-title"><div><span class="section-icon">💳</span><h3>زما اخیستل شوي کورسونه</h3></div><span class="count-badge">'+purchaseList.length+'</span></div>'+
        items(purchaseList,"تر اوسه کوم کورس نه دی اخیستل شوی",x=>
          '<div class="purchase-card"><div class="purchase-icon">✓</div><div class="item-main"><b>'+esc(x.courseTitle||x.title||x.courseId||"کورس")+'</b><span>د پیرود حالت</span></div><div class="active-badge">'+esc(x.status||"فعال")+'</div></div>'
        )+
      '</section>'+

      '<section class="dash-section notification-section">'+
        '<div class="section-title"><div><span class="section-icon">🔔</span><h3>خبرتیاوې</h3></div><span class="count-badge">'+notificationList.length+'</span></div>'+
        items(notificationList,"تر اوسه خبرتیا نشته",x=>
          '<div class="notification-card"><div class="notification-icon">🔔</div><div><b>'+esc(x.title||"خبرتیا")+'</b><p>'+esc(x.message||x.text||"")+'</p></div></div>'
        )+
      '</section>';

  }catch(e){
    console.error("Dashboard error:",e);
    c.innerHTML=
      '<div class="card">'+
        '<h2>Dashboard</h2>'+
        '<p>Dashboard په بریالیتوب سره چمتو نه شو.</p>'+
        '<button onclick="showDashboard(user)">بیا هڅه</button>'+
      '</div>';
  }
}

(async function restoreLogin(){
  try{
    const token=localStorage.getItem("zd")||localStorage.getItem("zd_token");
    if(!token)return;

    const r=await fetch(API+"/api/me",{
      headers:{Authorization:"Bearer "+token}
    });

    if(!r.ok){
      localStorage.removeItem("zd");
      localStorage.removeItem("zd_token");
      localStorage.removeItem("zd_user");
      return;
    }

    const d=await r.json();
    if(d.user){
      localStorage.setItem("zd",token);
      localStorage.setItem("zd_token",token);
      localStorage.setItem("zd_user",JSON.stringify(d.user));
      showDashboard(d.user);
    }
  }catch(e){
    console.error("Session restore error:",e);
  }
})();
